package com.health.kidneysuraksha;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;

public class RecommendationsActivity extends AppCompatActivity {

    private RecyclerView recyclerViewRecommendations;
    private ArticlesAdapter articlesAdapter;
    private List<Article> articleList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommendations);

        recyclerViewRecommendations = findViewById(R.id.recyclerViewRecommendations);
        recyclerViewRecommendations.setLayoutManager(new LinearLayoutManager(this));
        articleList = new ArrayList<>();
        articlesAdapter = new ArticlesAdapter(articleList, this);
        recyclerViewRecommendations.setAdapter(articlesAdapter);

        db = FirebaseFirestore.getInstance();

        loadRecommendedArticles();
    }

    private void loadRecommendedArticles() {
        // For demonstration, we use user_id = 1
        List<Integer> recommendedUserIds = getAdvancedRecommendations(userId);

        for (Integer userId : recommendedUserIds) {
            db.collection("articles")
                    .whereEqualTo("user_id", userId)
                    .get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Article article = document.toObject(Article.class);
                                articleList.add(article);
                            }
                            articlesAdapter.notifyDataSetChanged();
                        }
                    });
        }
    }

    private List<Integer> getRecommendations(int userId) {
        // Example recommendation logic
        List<Integer> recommendedUserIds = new ArrayList<>();
        // Add logic to fetch recommended user IDs based on user behavior, preferences, and reading history
        // For demonstration, we use a static list of user IDs
        recommendedUserIds.add(1);
        recommendedUserIds.add(2);
        recommendedUserIds.add(3);
        return recommendedUserIds;
    }
}
