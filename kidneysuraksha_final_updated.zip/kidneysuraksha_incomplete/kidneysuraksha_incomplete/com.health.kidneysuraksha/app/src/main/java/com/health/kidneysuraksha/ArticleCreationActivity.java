package com.health.kidneysuraksha;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.util.HashMap;
import java.util.Map;
import jp.wasabeef.richeditor.RichEditor;

public class ArticleCreationActivity extends AppCompatActivity {

    private EditText editTextTitle;
    private RichEditor richEditorContent;
    private Button buttonSave, buttonAddImage, buttonAddVideo;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_creation);

        editTextTitle = findViewById(R.id.editTextTitle);
        richEditorContent = findViewById(R.id.richEditorContent);
        buttonSave = findViewById(R.id.buttonSave);
        buttonAddImage = findViewById(R.id.buttonAddImage);
        buttonAddVideo = findViewById(R.id.buttonAddVideo);

        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = editTextTitle.getText().toString().trim();
                String content = richEditorContent.getHtml();

                if (title.isEmpty() || content.isEmpty()) {
                    Toast.makeText(ArticleCreationActivity.this, "Title and content cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                saveArticle(title, content);
            }
        });

        buttonAddImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add image handling logic
            }
        });

        buttonAddVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add video handling logic
            }
        });
    }

    private void saveArticle(String title, String content) {
        Map<String, Object> article = new HashMap<>();
        article.put("title", title);
        article.put("content", content);

        db.collection("articles")
                .add(article)
                .addOnSuccessListener(documentReference -> Toast.makeText(ArticleCreationActivity.this, "Article saved", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(ArticleCreationActivity.this, "Error saving article: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
