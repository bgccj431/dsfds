package com.health.kidneysuraksha;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;

public class TrendingArticlesActivity extends AppCompatActivity {

    private RecyclerView recyclerViewTrendingArticles;
    private ArticlesAdapter articlesAdapter;
    private List<Article> articleList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trending_articles);

        recyclerViewTrendingArticles = findViewById(R.id.recyclerViewTrendingArticles);
        recyclerViewTrendingArticles.setLayoutManager(new LinearLayoutManager(this));
        articleList = new ArrayList<>();
        articlesAdapter = new ArticlesAdapter(articleList, this);
        recyclerViewTrendingArticles.setAdapter(articlesAdapter);

        db = FirebaseFirestore.getInstance();

        loadTrendingArticles();
    }

    private void loadTrendingArticles() {
        db.collection("articles")
                .orderBy("likes", Query.Direction.DESCENDING)
                .limit(10)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        articleList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Article article = document.toObject(Article.class);
                            articleList.add(article);
                        }
                        articlesAdapter.notifyDataSetChanged();
                    }
                });
    }
}
