package com.health.kidneysuraksha;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class ProfileCustomizationActivity extends AppCompatActivity {

    private EditText editTextBio, editTextAvatarUrl, editTextSocialLinks;
    private Button buttonSaveProfile;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_customization);

        editTextBio = findViewById(R.id.editTextBio);
        editTextAvatarUrl = findViewById(R.id.editTextAvatarUrl);
        editTextSocialLinks = findViewById(R.id.editTextSocialLinks);
        buttonSaveProfile = findViewById(R.id.buttonSaveProfile);

        db = FirebaseFirestore.getInstance();

        buttonSaveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bio = editTextBio.getText().toString().trim();
                String avatarUrl = editTextAvatarUrl.getText().toString().trim();
                String socialLinks = editTextSocialLinks.getText().toString().trim();

                if (TextUtils.isEmpty(bio) || TextUtils.isEmpty(avatarUrl) || TextUtils.isEmpty(socialLinks)) {
                    Toast.makeText(ProfileCustomizationActivity.this, "All fields are required.", Toast.LENGTH_SHORT).show();
                    return;
                }

                saveUserProfile(bio, avatarUrl, socialLinks);
            }
        });
    }

    private void saveUserProfile(String bio, String avatarUrl, String socialLinks) {
        Map<String, Object> userProfile = new HashMap<>();
        userProfile.put("bio", bio);
        userProfile.put("avatarUrl", avatarUrl);
        userProfile.put("socialLinks", socialLinks);

        String userId = "user_id"; // Replace with actual user ID
        db.collection("user_profiles")
                .document(userId)
                .set(userProfile)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(ProfileCustomizationActivity.this, "Profile saved successfully.", Toast.LENGTH_SHORT).show();
                    // Redirect to main activity or clear fields
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ProfileCustomizationActivity.this, "Error saving profile: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });

        // Fetch and display user profile information
        db.collection("user_profiles")
                .document(userId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String bio = documentSnapshot.getString("bio");
                        String avatarUrl = documentSnapshot.getString("avatarUrl");
                        String socialLinks = documentSnapshot.getString("socialLinks");

                        editTextBio.setText(bio);
                        editTextAvatarUrl.setText(avatarUrl);
                        editTextSocialLinks.setText(socialLinks);
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ProfileCustomizationActivity.this, "Error fetching profile: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
